//
//  RecipeTests.swift
//  RecipeTests
//
//  Created by Grant David Hughes on 6/25/25.
//

import Testing
@testable import Recipe

struct RecipeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
