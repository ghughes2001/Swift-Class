//
//  calculator2Tests.swift
//  calculator2Tests
//
//  Created by Grant David Hughes on 6/30/25.
//

import Testing
@testable import calculator2

struct calculator2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
